<?php

//import.php

if(!empty($_FILES['csv_file']['name']))
{
$file_data = fopen($_FILES['csv_file']['tmp_name'], 'r');
 fgetcsv($file_data);
 while($row = fgetcsv($file_data))
 {
  $data[] = array(
    's_no'  => $row[0],
    'name'  => $row[1],
    'empanelment_number'  => $row[2]
  );
 }
 echo json_encode($data);
}

?>